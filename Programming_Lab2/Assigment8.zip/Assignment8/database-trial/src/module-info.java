/**
 * 
 */
/**
 * @author oneautumleaf
 *
 */
module database_trial {
	requires java.sql;
}