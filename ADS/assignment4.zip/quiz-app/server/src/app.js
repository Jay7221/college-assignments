// server.js

const express = require("express");
const bodyParser = require("body-parser");
const authRouter = require("./routers/authRoutes");
const quizStudentRouter = require("./routers/quizStudentRoutes");
const quizTeacherRouter = require("./routers/quizTeacherRoutes");
const authMiddleware = require("./middleware/authMiddleware");
const teacherMiddleware = require("./middleware/teacherMiddleware");
const cors = require("cors"); // Import CORS middleware

const app = express();

app.use(bodyParser.json());
app.use(cors()); // Enable CORS for all routes

// Mount routers
app.use("/api", authRouter);
app.use("/api", authMiddleware, quizStudentRouter);
app.use("/api", authMiddleware, teacherMiddleware, quizTeacherRouter);

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
