const { DataTypes } = require("sequelize");
const sequelize = require("../db/conn");
const { Quiz } = require("./quiz");
const { User } = require("./user");

const Submission = sequelize.define("Submission", {
  quizId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    refrences: {
      model: Quiz,
      key: "id",
    },
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    refrences: {
      model: User,
      key: "id",
    },
  },
  answers: {
    type: DataTypes.JSON,
    allowNull: false,
  },
  marksObtained: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
});

module.exports = Submission;
