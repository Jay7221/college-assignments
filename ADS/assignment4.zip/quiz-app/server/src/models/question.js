const { DataTypes } = require("sequelize");
const sequelize = require("../db/conn");

const Question = sequelize.define("Question", {
  description: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  image: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  options: {
    type: DataTypes.JSON,
    allowNull: false,
  },
  correctOption: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  marks: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
});

module.exports = Question;
