const { DataTypes } = require("sequelize");

const sequelize = require("../db/conn");
const Question = require("./question");

const Quiz = sequelize.define("Quiz", {
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  subject: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  totalQuestions: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
});

Quiz.hasMany(Question, {
  foreignKey: {
    name: "quizId",
    allowNull: false,
  },
  onDelete: "CASCADE",
});

module.exports = Quiz;
