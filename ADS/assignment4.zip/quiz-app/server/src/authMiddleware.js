// authMiddleware.js

const jwt = require("jsonwebtoken");

const authenticateTeacher = (req, res, next) => {
  // Extract the token from the request headers
  const token =
    req.headers.authorization && req.headers.authorization.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Authorization token is missing" });
  }

  try {
    // Verify the token
    const decodedToken = jwt.verify(token, "your_secret_key");

    // Assuming decodedToken contains user information including the role
    const { role } = decodedToken;

    if (role === "teacher") {
      // User is a teacher, proceed to the next middleware/route handler
      req.user = decodedToken; // Optional: Attach user information to the request object
      next();
    } else {
      // User is not authorized, respond with a 403 Forbidden error
      return res
        .status(403)
        .json({ message: "You are not authorized to access this resource" });
    }
  } catch (error) {
    // Token is invalid or expired
    console.error("Error verifying JWT token:", error);
    return res.status(401).json({ message: "Invalid token" });
  }
};

module.exports = { authenticateTeacher };
