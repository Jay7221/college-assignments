const express = require("express");
const router = express.Router();
const Quiz = require("../models/quiz");
const Question = require("../models/question");
const Submission = require("../models/submission");

router.get("/quizzes", async (req, res) => {
    try {
        const quizzes = await Quiz.findAll({
            attributes: ["id", "name", "totalQuestions", "subject"],
        });
        res.json(quizzes);
    } catch (error) {
        console.log(`Error fetching quizzes: ${error}`);
        res.status(500).json({ message: "Server error" });
    }
});

router.get("/submissions", async (req, res) => {
    const userId = req.user.id;
    try {
        const submissions = await Submission.findAll({ where: { userId } });
        res.json(submissions);
    }
    catch (error) {
        console.log("Error fetching submissions: ", error);
        res.status(500).json({ message: "Server error" });
    }
})

router.get("/quizzes/:quizId/questions", async (req, res) => {
    const { quizId } = req.params;
    try {
        const quiz = await Quiz.findByPk(quizId);
        if (!quiz) {
            return res.status(404).json({ message: "Quiz not found" });
        }
        const questions = await Question.findAll({
            where: { quizId },
            attributes: ["id", "description", "image", "options"],
        });
        res.json(questions);
    } catch (error) {
        console.log(`Error fetching questions of quiz ${quizId}: ${error}`);
        res.status(500).json({ message: "Server error" });
    }
});

router.get("/submission/:submissionId", async (req, res) => {
    const { submissionId } = req.params;
    try {
        const submission = await Submission.findByPk(submissionId);
        if (!submission) {
            return res.status(404).json({ message: "Submission not found" });
        }
        res.json(submission);
    }
    catch (error) {
        console.log(`Error fetching submission ${submissionId}: ${error}`);
        res.status(500).json({ message: "Server error" });
    }

});

router.post("/quizzes/:quizId/submit", async (req, res) => {
    const { quizId } = req.params;
    const userId = req.user.id;
    const { answers } = req.body;
    try {
        const questions = await Question.findAll({ where: { quizId } });
        let marksObtained = 0;

        questions.forEach((question) => {
            const correctOption = question.correctOption;
            const submittedOption = answers[question.id];
            if (submittedOption && correctOption === submittedOption) {
                marksObtained += question.marks;
            }
        });
        const submission = await Submission.create({
            quizId,
            userId,
            answers,
            marksObtained,
        });

        res.status(201).json(submission);
    } catch (error) {
        console.log("Error submitting solutions: ", error);
        res.status(500).json({ message: "Server error" });
    }
});


module.exports = router;
