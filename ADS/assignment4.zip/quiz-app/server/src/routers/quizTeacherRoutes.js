const express = require("express");
const router = express.Router();
const Quiz = require("../models/quiz");
const Question = require("../models/question");

router.post("/quizzes", async (req, res) => {
    console.log("Creating a quiz...");
    const { name, subject, totalQuestions } = req.body;
    try {
        const newQuiz = await Quiz.create({ name, subject, totalQuestions });
        res.status(201).json(newQuiz);
    } catch (error) {
        console.log(`Error adding quizzes: ${error}`);
        res.status(500).json({ message: "Server error" });
    }
});

router.post("/quizzes/:quizId/questions", async (req, res) => {
    console.log("Adding a question ...");
    const { quizId } = req.params;
    const { description, image, options, marks, correctOption } = req.body;
    try {
        const quiz = await Quiz.findByPk(quizId);
        if (!quiz) {
            return res.status(404).json({ message: "Quiz not found" });
        }
        const newQuestion = await Question.create({
            description,
            image,
            options,
            marks,
            quizId,
            correctOption,
        });
        res.json(newQuestion);
    } catch (error) {
        console.log(`Error adding question: ${error}`);
        res.status(500).json({ message: "Server error" });
    }
});

module.exports = router;
