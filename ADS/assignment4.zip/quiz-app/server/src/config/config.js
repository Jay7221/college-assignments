module.exports = {
    development: {
        username: "root",
        password: "Jay@1234",
        database: "ads_sample",
        host: "localhost",
        dialect: "mysql",
    },
    jwtSecret: "My name is Jjay",
    forceSync: false,
};
