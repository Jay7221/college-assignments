import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import QuizPage from "./components/QuizPage";
import QuizComponent from "./components/QuizComponent";
import QuizCreationComponent from "./components/QuizCreationComponent";
import Login from "./components/Login";
import Signup from "./components/Signup";
import SubmissionComponent from "./components/SubmissionComponent";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/home" element={<QuizPage />} />
        <Route path="/quiz/:quizId" element={<QuizComponent />} />
        <Route
          path="/submission/:submissionId"
          element={<SubmissionComponent />}
        />
        <Route path="/quiz-create" element={<QuizCreationComponent />} />
      </Routes>
    </Router>
  );
};

export default App;
