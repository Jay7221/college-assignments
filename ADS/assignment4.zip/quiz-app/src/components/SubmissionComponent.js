import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { fetchSubmission, fetchQuestionsForQuiz } from "../api/quiz/quizApi";
import "./SubmissionComponent.css";

const SubmissionComponent = () => {
  const { submissionId } = useParams();

  const [submissionData, setSubmissionData] = useState(null);
  const [questions, setQuestions] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const submission = await fetchSubmission(submissionId);
        setSubmissionData(submission);
        const quizQuestions = await fetchQuestionsForQuiz(submission.quizId);
        setQuestions(quizQuestions);
        console.log(quizQuestions);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [submissionId]);

  if (!questions) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="submission-container">
      <h1 className="title">Quiz Submission</h1>
      <div className="submission-info">
        <p>Total Marks Obtained: {submissionData.marksObtained}</p>
      </div>
      <div className="questions">
        {questions.map((question) => (
          <div className="question" key={question.id}>
            <h2>{question.description}</h2>
            {question.image && <img src={question.image} alt="Question" />}
            <div className="options">
              {Object.entries(question.options).map(([optionId, option]) => (
                <button
                  key={optionId}
                  className={`option ${
                    submissionData.answers[question.id] === optionId
                      ? "selected"
                      : ""
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
            <p className="selected-option">
              Selected Option:{" "}
              {submissionData.answers[question.id] || "Not Attempted"}
            </p>
          </div>
        ))}
      </div>
      <a href="/home">Home</a>
    </div>
  );
};

export default SubmissionComponent;
