import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "./QuizComponent.css";
import { fetchQuestionsForQuiz, submitQuiz } from "../api/quiz/quizApi";

const QuizComponent = () => {
  const { quizId } = useParams();
  const navigate = useNavigate();

  const [quizData, setQuizData] = useState(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOptions, setSelectedOptions] = useState({});
  const [timer, setTimer] = useState(600);

  useEffect(() => {
    const fetchQuizData = async () => {
      try {
        const data = await fetchQuestionsForQuiz(quizId);
        setQuizData(data);
        setSelectedOptions(new Array(data.length));
      } catch (error) {
        console.error("Error fetching quiz data:", error);
      }
    };

    fetchQuizData();

    const timerInterval = setInterval(() => {
      setTimer((prevTimer) => {
        if (prevTimer > 0) {
          return prevTimer - 1;
        } else {
          clearInterval(timerInterval);
          // Optionally, you can automatically submit the quiz when time runs out
          submitQuiz();
          return 0;
        }
      });
    }, 1000);

    return () => clearInterval(timerInterval);
  }, [quizId]);

  const handleOptionSelect = (optionId) => {
    setSelectedOptions((prevSelectedOptions) => ({
      ...prevSelectedOptions,
      [currentQuestionIndex]: optionId,
    }));
  };

  const handlePrevQuestion = () => {
    setCurrentQuestionIndex((prevIndex) => Math.max(prevIndex - 1, 0));
  };

  const handleNextQuestion = () => {
    setCurrentQuestionIndex((prevIndex) =>
      Math.min(prevIndex + 1, quizData.length - 1)
    );
  };

  const handleSubmitQuiz = async () => {
    const answers = {};
    for (let i = 0; i < quizData.length; ++i) {
      answers[quizData[i].id] = selectedOptions[i];
    }
    const submissionResult = await submitQuiz(quizId, answers);
    navigate(`/submission/${submissionResult.id}`);
  };
  if (!quizData) {
    return <div>Loading...</div>;
  }

  if (quizData.length === 0) {
    return <div>This quiz has yet to get any questions ...</div>;
  }
  const currentQuestion = quizData[currentQuestionIndex];
  const isFirstQuestion = currentQuestionIndex === 0;
  const isLastQuestion = currentQuestionIndex === quizData.length - 1;

  return (
    <div className="quiz-container">
      <div className="question">
        <p>{currentQuestion.id}</p>
        <h2>{currentQuestion.description}</h2>
        {currentQuestion.image && (
          <img src={currentQuestion.image} alt="Question" />
        )}
      </div>
      <div className="options">
        {Object.entries(currentQuestion.options).map(
          ([optionId, optionDescription]) => (
            <button
              key={optionId}
              onClick={() => handleOptionSelect(optionId)}
              className={
                selectedOptions[currentQuestionIndex] === optionId
                  ? "selected"
                  : ""
              }
            >
              {optionDescription}
            </button>
          )
        )}
      </div>
      <div className="actions">
        {!isFirstQuestion && (
          <button onClick={handlePrevQuestion} className="prev">
            Prev
          </button>
        )}
        {isLastQuestion ? (
          <button onClick={handleSubmitQuiz} className="submit">
            Submit
          </button>
        ) : (
          <button onClick={handleNextQuestion} className="next">
            Next
          </button>
        )}
      </div>
      <div className="timer">
        <span>
          Timer: {Number.parseInt(timer / 60)} : {timer % 60}
        </span>
      </div>
    </div>
  );
};

export default QuizComponent;
