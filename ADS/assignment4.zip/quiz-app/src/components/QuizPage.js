import React, { useEffect, useState } from "react";
import "./QuizPage.css"; // Import CSS file for styling
import { fetchQuizList } from "../api/quiz/quizApi";

const QuizPage = () => {
  // Placeholder for quiz data fetched from API
  const [quizzes, setQuizzes] = useState([]);

  // Placeholder for fetching quiz data from API
  useEffect(() => {
    // Fetch quiz data from API endpoint
    // Replace this with actual API call
    const fetchQuizzes = async () => {
      // Example API endpoint
      try {
        const quizData = await fetchQuizList();
        setQuizzes(quizData);
      } catch (error) {
        console.error("Error fetching quiz data:", error);
      }
    };

    // Call the function to fetch quizzes when component mounts
    fetchQuizzes();
  }, []);

  return (
    <div className="quiz-page">
      <nav className="navbar">
        <div className="navbar-left">
          <a href="/home" className="nav-link">
            Home
          </a>{" "}
          {/* Redirect to /home */}
          <a href="/dashboard" className="nav-link">
            Dashboard
          </a>{" "}
          {/* Redirect to /dashboard */}
        </div>
        <div className="navbar-right">
          <a href="/profile" className="nav-link profile-link">
            Profile
          </a>{" "}
          {/* Redirect to /profile */}
        </div>
      </nav>
      <main className="main-content">
        {quizzes.map((quiz) => (
          <a key={quiz.id} href={`quiz/${quiz.id}`} className="quiz-card">
            <img
              src="logo192.png"
              alt={quiz.subject}
              className="subject-image"
            />
            <div className="quiz-info">
              <h3 className="quiz-name">{quiz.name}</h3>
              <p className="subject-name">{quiz.subject}</p>
            </div>
          </a>
        ))}
      </main>
    </div>
  );
};

export default QuizPage;
