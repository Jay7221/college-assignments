import React, { useState } from "react";
import "./QuizCreationComponent.css";
import { useNavigate } from "react-router-dom";
import { addQuestionToQuiz, createQuiz } from "../api/quiz/quizApi";

const QuizCreationComponent = () => {
  const [quizName, setQuizName] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [questions, setQuestions] = useState([]);
  const [newQuestion, setNewQuestion] = useState({
    text: "",
    includeImage: false,
    imageFile: null,
    marks: "",
    options: [],
    correctOption: null,
  });
  const navigate = useNavigate();

  const [editQuestion, setEditQuestion] = useState({
    text: "",
    includeImage: false,
    imageFile: null,
    marks: "",
    options: [],
    correctOption: null,
  });
  const [editIndex, setEditIndex] = useState(null); // Track the index of the question being edited

  const handleAddQuestion = () => {
    if (
      newQuestion.text.trim() === "" ||
      newQuestion.marks.trim() === "" ||
      newQuestion.options.length < 2 ||
      newQuestion.correctOption === null
    ) {
      return;
    }
    setQuestions([...questions, newQuestion]);
    setNewQuestion({
      text: "",
      includeImage: false,
      imageFile: null,
      marks: "",
      options: [],
      correctOption: null,
    });
  };

  const handleDeleteQuestion = (index) => {
    const updatedQuestions = [...questions];
    updatedQuestions.splice(index, 1);
    setQuestions(updatedQuestions);
    if (editIndex === index) {
      setEditIndex(null); // Reset editIndex if the deleted question is being edited
    }
  };

  const handleEditQuestion = (index) => {
    const question = questions[index];
    setEditQuestion({
      text: question.text,
      includeImage: question.includeImage,
      imageFile: question.imageFile,
      marks: question.marks,
      options: question.options,
      correctOption: question.correctOption,
    });
    setEditIndex(index);
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setNewQuestion((prevQuestion) => ({
      ...prevQuestion,
      imageFile: file,
    }));
    setEditQuestion((prevQuestion) => ({
      ...prevQuestion,
      imageFile: file,
    }));
  };

  const handleSaveEdit = () => {
    // Save edits when editing a question
    questions[editIndex] = editQuestion;
    setEditIndex(null);
  };
  const handleAddOption = () => {
    setEditQuestion((prevQuestion) => ({
      ...prevQuestion,
      options: [...prevQuestion.options, ""],
    }));
  };

  const handleOptionChange = (value, index) => {
    setEditQuestion((prevQuestion) => {
      const updatedOptions = [...prevQuestion.options];
      updatedOptions[index] = value;
      return {
        ...prevQuestion,
        options: updatedOptions,
      };
    });
  };

  const handleDeleteOption = (index) => {
    setEditQuestion((prevQuestion) => {
      const updatedOptions = [...prevQuestion.options];
      updatedOptions.splice(index, 1);
      return {
        ...prevQuestion,
        options: updatedOptions,
      };
    });
  };
  const handleNewAddOption = () => {
    setNewQuestion((prevQuestion) => ({
      ...prevQuestion,
      options: [...prevQuestion.options, ""],
    }));
  };

  const handleNewOptionChange = (value, index) => {
    setNewQuestion((prevQuestion) => {
      const updatedOptions = [...prevQuestion.options];
      updatedOptions[index] = value;
      return {
        ...prevQuestion,
        options: updatedOptions,
      };
    });
  };

  const handleNewDeleteOption = (index) => {
    setNewQuestion((prevQuestion) => {
      const updatedOptions = [...prevQuestion.options];
      updatedOptions.splice(index, 1);
      return {
        ...prevQuestion,
        options: updatedOptions,
      };
    });
  };

  const handleSubmit = async () => {
    const quizData = {
      name: quizName,
      subject: selectedSubject,
      totalQuestions: questions.length,
    };
    const newQuiz = await createQuiz(quizData);
    const quizId = newQuiz.id;

    questions.forEach(async (question) => {
      console.log(questions);
      const questionData = {
        description: question.text,
        image: question.imageFile,
        options: question.options,
        marks: question.marks,
        correctOption: question.correctOption,
      };
      addQuestionToQuiz(quizId, questionData);
    });
    navigate("/home");
  };

  return (
    <div className="quiz-creation-container">
      <div className="quiz-header">
        <input
          type="text"
          value={quizName}
          placeholder="Quiz Name"
          onChange={(e) => setQuizName(e.target.value)}
        />
        <select
          value={selectedSubject}
          onChange={(e) => setSelectedSubject(e.target.value)}
        >
          <option value="">Select Subject</option>
          <option value="Machine Learning">Machine Learning</option>
          <option value="ADS">ADS</option>
          <option value="Soft Computing">Soft Computing</option>
        </select>
      </div>
      <div className="questions-container">
        {questions.map((question, index) => (
          <div key={index} className="question-card">
            {editIndex === index ? (
              <div className="edit-question-form">
                <input
                  type="text"
                  value={editQuestion.text}
                  placeholder="Enter Question"
                  onChange={(e) =>
                    setEditQuestion({
                      ...editQuestion,
                      text: e.target.value,
                    })
                  }
                />
                <input
                  type="checkbox"
                  checked={editQuestion.includeImage}
                  onChange={(e) =>
                    setEditQuestion({
                      ...editQuestion,
                      includeImage: e.target.checked,
                    })
                  }
                />
                Include Image
                {editQuestion.includeImage && (
                  <input type="file" onChange={handleFileChange} />
                )}
                <input
                  type="number"
                  value={editQuestion.marks}
                  placeholder="Marks"
                  onChange={(e) =>
                    setEditQuestion({
                      ...editQuestion,
                      marks: e.target.value,
                    })
                  }
                />
                {editQuestion.options.map((option, optionIndex) => (
                  <div key={optionIndex}>
                    <input
                      type="text"
                      value={option}
                      placeholder={`Option ${optionIndex + 1}`}
                      onChange={(e) =>
                        handleOptionChange(e.target.value, optionIndex)
                      }
                    />
                    <input
                      type="radio"
                      name="correctOption"
                      value={optionIndex}
                      checked={editQuestion.correctOption === optionIndex}
                      onChange={(e) =>
                        setEditQuestion({
                          ...editQuestion,
                          correctOption: parseInt(e.target.value),
                        })
                      }
                    />
                    Correct
                    <button onClick={() => handleDeleteOption(optionIndex)}>
                      Delete
                    </button>
                  </div>
                ))}
                <button onClick={handleAddOption}>Add Option</button>
                <button onClick={handleSaveEdit}>Save</button>
              </div>
            ) : (
              // Display question details
              <>
                <div className="question-text">{question.text}</div>
                {question.includeImage && (
                  <img
                    src={question.imageFile}
                    alt="Question"
                    className="question-image"
                  />
                )}
                <div className="question-marks">Marks: {question.marks}</div>
                <div className="question-options">
                  <ul>
                    {question.options.map((option, optionIndex) => (
                      <li key={optionIndex}>{option}</li>
                    ))}
                  </ul>
                </div>
                <div className="question-actions">
                  <button onClick={() => handleEditQuestion(index)}>
                    Edit
                  </button>
                  <button onClick={() => handleDeleteQuestion(index)}>
                    Delete
                  </button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>
      <div className="new-question-form">
        <input
          type="text"
          value={newQuestion.text}
          placeholder="Enter Question"
          onChange={(e) =>
            setNewQuestion({
              ...newQuestion,
              text: e.target.value,
            })
          }
        />
        <input
          type="checkbox"
          checked={newQuestion.includeImage}
          onChange={(e) =>
            setNewQuestion({
              ...newQuestion,
              includeImage: e.target.checked,
            })
          }
        />
        Include Image
        {newQuestion.includeImage && (
          <input type="file" onChange={handleFileChange} />
        )}
        <input
          type="number"
          value={newQuestion.marks}
          placeholder="Marks"
          onChange={(e) =>
            setNewQuestion({
              ...newQuestion,
              marks: e.target.value,
            })
          }
        />
        {newQuestion.options.map((option, optionIndex) => (
          <div key={optionIndex}>
            <input
              type="text"
              value={option}
              placeholder={`Option ${optionIndex + 1}`}
              onChange={(e) =>
                handleNewOptionChange(e.target.value, optionIndex)
              }
            />
            <input
              type="radio"
              name="correctOption"
              value={optionIndex}
              checked={newQuestion.correctOption === optionIndex}
              onChange={(e) =>
                setNewQuestion({
                  ...newQuestion,
                  correctOption: parseInt(e.target.value),
                })
              }
            />
            Correct
            <button onClick={() => handleNewDeleteOption(optionIndex)}>
              Delete
            </button>
          </div>
        ))}
        <button onClick={handleNewAddOption}>Add Option</button>
        <button onClick={handleAddQuestion}>Add Question</button>
      </div>
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
};

export default QuizCreationComponent;
