// Signup.js

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Signup.css"; // Import the CSS file for styles

const Signup = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("student");
  const [name, setName] = useState("");
  const [department, setDepartment] = useState("");
  const [salary, setSalary] = useState("");
  const [totalCredits, setTotalCredits] = useState("");

  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSignup = async () => {
    try {
      const response = await fetch("http://localhost:3001/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username,
          password,
          role,
          name,
          department,
          salary,
          totalCredits,
        }),
      });

      if (response.ok) {
        // Redirect to login or dashboard page after successful signup
        navigate("/login");
      } else {
        const data = await response.json();
        setError(
          data.error || "An error occurred during signup. Please try again."
        );
      }
    } catch (error) {
      console.error("Error during signup:", error);
      setError("An unexpected error occurred. Please try again.");
    }
  };

  return (
    <div className="signup-container">
      <h2 className="signup-heading">Signup</h2>
      <div className="form-group">
        <label className="label">Username:</label>
        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="input"
        />
      </div>
      <div className="form-group">
        <label className="label">Password:</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="input"
        />
      </div>
      <div className="form-group">
        <label className="label">Role:</label>
        <select
          value={role}
          onChange={(e) => setRole(e.target.value)}
          className="input"
        >
          <option value="student">Student</option>
          <option value="instructor">Instructor</option>
        </select>
      </div>
      <div className="form-group">
        <label className="label">Name:</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="input"
        />
      </div>
      {role === "instructor" && (
        <div className="form-group">
          <label className="label">Department:</label>
          <input
            type="text"
            value={department}
            onChange={(e) => setDepartment(e.target.value)}
            className="input"
          />
        </div>
      )}
      {role === "instructor" && (
        <div className="form-group">
          <label className="label">Salary:</label>
          <input
            type="text"
            value={salary}
            onChange={(e) => setSalary(e.target.value)}
            className="input"
          />
        </div>
      )}
      {role === "student" && (
        <div className="form-group">
          <label className="label">Total Credits:</label>
          <input
            type="text"
            value={totalCredits}
            onChange={(e) => setTotalCredits(e.target.value)}
            className="input"
          />
        </div>
      )}
      <div>
        <button onClick={handleSignup} className="signup-button">
          Signup
        </button>
      </div>
      {error && <p className="error">{error}</p>}
    </div>
  );
};

export default Signup;
