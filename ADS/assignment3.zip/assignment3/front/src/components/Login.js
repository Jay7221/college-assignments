// Login.js

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css"; // Import the CSS file for styles

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const response = await fetch("http://localhost:3001/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      });

      if (response.ok) {
        const data = await response.json();
        // Redirect based on the user's role (customize as needed)
        if (data.role === "student") {
          navigate(`/student/${response.data.studentId}`);
        } else if (data.role === "instructor") {
          navigate("/instructor-dashboard");
        }
      } else {
        setError("Invalid credentials. Please try again.");
      }
    } catch (error) {
      console.error("Error during login:", error);
      setError("An error occurred. Please try again later.");
    }
  };

  return (
    <div className="login-container">
      <h2 className="login-heading">Login</h2>
      <div className="form-group">
        <label className="label">
          Username:
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="input"
          />
        </label>
      </div>
      <div className="form-group">
        <label className="label">
          Password:
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input"
          />
        </label>
      </div>
      <div>
        <button onClick={handleLogin} className="login-button">
          Login
        </button>
      </div>
      {error && <p className="error">{error}</p>}
    </div>
  );
};

export default Login;
