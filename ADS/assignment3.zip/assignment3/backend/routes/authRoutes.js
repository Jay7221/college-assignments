// authRouter.js

const express = require("express");
const { Instructor, Student } = require("../models"); // Adjust the path based on your project structure

const authRouter = express.Router();

authRouter.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    // Check if the user is an instructor
    const instructor = await Instructor.findOne({
      where: { ID: username, password: password },
    });

    if (instructor) {
      res.json({ role: "instructor" });
      return;
    }

    // Check if the user is a student
    const student = await Student.findOne({
      where: { ID: username, password: password },
    });

    if (student) {
      res.json({ role: "student" });
    } else {
      res.status(401).json({ error: "Invalid credentials" });
    }
  } catch (error) {
    console.error("Error during login:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// Signup endpoint
authRouter.post("/signup", async (req, res) => {
  const { username, password, role, name, department, salary, totalCredits } =
    req.body;

  try {
    if (role === "instructor") {
      // Add logic to insert into the instructor table
      await Instructor.create({
        ID: username,
        name,
        dept_name: department,
        salary,
        password,
      });
    } else if (role === "student") {
      // Add logic to insert into the student table
      await Student.create({
        ID: username,
        name,
        dept_name: department,
        tot_cred: totalCredits,
        password,
      });
    } else {
      return res.status(400).json({ error: "Invalid role specified" });
    }

    // You can add additional logic or validation as needed

    return res.status(201).json({ success: true });
  } catch (error) {
    console.error("Error during signup:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = authRouter;
